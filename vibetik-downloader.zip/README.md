# VibeTik Full-Stack Downloader

This is a complete, full-stack application for downloading TikTok videos. It consists of a React frontend and a Node.js/Express backend that handles the video scraping.

## Project Structure
- **/ (root)**: Contains the React frontend source files (`index.tsx`, `App.tsx`, etc.).
- **/backend**: Contains the Node.js/Express server source files.
- **/dist**: This folder is created after building. It contains the complete, runnable application, with the compiled backend server and the bundled frontend assets.

## How to Run for Production

This is how you would run the application on a web host or locally to simulate a production environment.

1.  **Install All Dependencies:**
    This command will install the root-level development tools and also automatically run `npm install` inside the `backend` directory.
    ```bash
    npm install
    ```

2.  **Build the Application:**
    This command builds both the frontend and backend into the `/dist` directory.
    ```bash
    npm run build
    ```

3.  **Start the Server:**
    This command runs the compiled server, which serves the frontend and handles API requests.
    ```bash
    npm start
    ```

4.  **Access the App:**
    Open your browser and navigate to `http://localhost:3001`.

## How to Run for Development

This setup is ideal for working on the code. It starts both the backend and frontend with live-reloading, so changes you make are reflected automatically.

1.  **Install All Dependencies:**
    (If you haven't already)
    ```bash
    npm install
    ```

2.  **Start the Development Servers:**
    This single command starts both the backend server (on port 3001) and the frontend dev server (on port 8000) concurrently.
    ```bash
    npm run dev
    ```

3.  **Access the App:**
    - The backend API is available at `http://localhost:3001`.
    - The frontend is available at `http://localhost:8000`. Open this URL in your browser. The frontend is configured to automatically talk to the backend on port 3001.
