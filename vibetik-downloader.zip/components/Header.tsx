
import React from 'react';
import { TikTokIcon } from './Icons';

export const Header: React.FC = () => {
  return (
    <header className="py-4 px-6 bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50 border-b border-slate-700/50">
      <div className="container mx-auto flex items-center justify-center sm:justify-start">
        <div className="flex items-center space-x-3">
          <TikTokIcon className="h-8 w-8 text-white" />
          <span className="text-2xl font-bold text-white tracking-tight">VibeTik</span>
        </div>
      </div>
    </header>
  );
};
