import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full py-6 mt-16 border-t border-slate-800">
      <div className="container mx-auto text-center text-gray-500">
        <p>&copy; {new Date().getFullYear()} VibeTik Downloader. All Rights Reserved.</p>
      </div>
    </footer>
  );
};
