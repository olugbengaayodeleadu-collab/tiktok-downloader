
export interface VideoInfo {
  title: string;
  author: string;
  thumbnailUrl: string;
  downloadUrls: {
    noWatermark: string;
    withWatermark: string;
    mp3: string;
  };
}
