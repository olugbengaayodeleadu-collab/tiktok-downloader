
import React from 'react';

export const HowToUse: React.FC = () => {
    return (
        <section className="w-full bg-slate-900 py-16 px-4">
            <div className="container mx-auto max-w-4xl text-center">
                <h2 className="text-3xl font-bold mb-8 text-white">How to Download a TikTok Video</h2>
                <div className="grid md:grid-cols-3 gap-8 text-left">
                    <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
                        <div className="flex items-center mb-4">
                            <span className="flex items-center justify-center h-10 w-10 rounded-full bg-blue-500 text-white font-bold text-xl mr-4">1</span>
                            <h3 className="text-xl font-semibold">Find a Video</h3>
                        </div>
                        <p className="text-gray-400">Open the TikTok app or website and find the video you want to download.</p>
                    </div>
                    <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
                        <div className="flex items-center mb-4">
                            <span className="flex items-center justify-center h-10 w-10 rounded-full bg-blue-500 text-white font-bold text-xl mr-4">2</span>
                            <h3 className="text-xl font-semibold">Copy the Link</h3>
                        </div>
                        <p className="text-gray-400">Tap the "Share" button on the video and then select "Copy Link".</p>
                    </div>
                    <div className="bg-slate-800 p-6 rounded-lg border border-slate-700">
                        <div className="flex items-center mb-4">
                            <span className="flex items-center justify-center h-10 w-10 rounded-full bg-blue-500 text-white font-bold text-xl mr-4">3</span>
                            <h3 className="text-xl font-semibold">Paste and Download</h3>
                        </div>
                        <p className="text-gray-400">Paste the link into the input box on this page and click the "Download" button.</p>
                    </div>
                </div>
            </div>
        </section>
    );
};
