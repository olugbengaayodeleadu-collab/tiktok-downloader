
import React from 'react';
import type { VideoInfo } from '../types';
import { DownloadIcon, MusicNoteIcon } from './Icons';

interface ResultCardProps {
  videoInfo: VideoInfo;
}

const DownloadButton: React.FC<{ href: string; text: string; icon: React.ReactNode }> = ({ href, text, icon }) => (
    <a
        href={href}
        download
        target="_blank"
        rel="noopener noreferrer"
        className="w-full flex items-center justify-center gap-3 px-6 py-3 text-base font-semibold text-white bg-blue-600 rounded-lg shadow-md hover:bg-blue-700 transform hover:-translate-y-0.5 transition-all duration-300 ease-in-out"
    >
        {icon}
        {text}
    </a>
);


export const ResultCard: React.FC<ResultCardProps> = ({ videoInfo }) => {
  return (
    <div className="w-full max-w-2xl bg-slate-800/50 border border-slate-700 rounded-xl shadow-2xl p-6 animate-fade-in">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-1/3 flex-shrink-0">
          <img
            src={videoInfo.thumbnailUrl}
            alt={videoInfo.title}
            className="rounded-lg w-full h-auto object-cover aspect-[9/16] shadow-lg"
          />
        </div>
        <div className="md:w-2/3 flex flex-col justify-between text-left">
            <div>
              <p className="text-gray-400 text-sm mb-1">@{videoInfo.author}</p>
              <h2 className="text-xl font-bold text-white line-clamp-2">
                {videoInfo.title}
              </h2>
            </div>
            <div className="mt-6 flex flex-col gap-3">
                <DownloadButton
                    href={videoInfo.downloadUrls.noWatermark}
                    text="Download (No Watermark)"
                    icon={<DownloadIcon className="h-5 w-5" />}
                />
                <DownloadButton
                    href={videoInfo.downloadUrls.withWatermark}
                    text="Download (With Watermark)"
                    icon={<DownloadIcon className="h-5 w-5" />}
                />
                <DownloadButton
                    href={videoInfo.downloadUrls.mp3}
                    text="Download MP3"
                    icon={<MusicNoteIcon className="h-5 w-5" />}
                />
            </div>
        </div>
      </div>
    </div>
  );
};

// Add fade-in animation to tailwind config or a style tag if not possible.
// For simplicity, let's add it via a style tag in index.html, or define it here if we were using a CSS file.
// For now, let's assume a global animation class `animate-fade-in` exists.
// A simple keyframe definition:
// @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
// .animate-fade-in { animation: fadeIn 0.5s ease-out forwards; }
// In a real project, this would be in a CSS file. We can't add a style tag, so we'll rely on the class name.
