import type { VideoInfo } from '../types';

// In development, the frontend and backend are on different ports (e.g., 8000 and 3001).
// In production, the backend serves the frontend, so they share the same origin.
// This logic automatically handles both cases.
const API_BASE_URL = window.location.hostname === 'localhost' ? 'http://localhost:3001' : '';

export async function fetchVideoInfo(url: string): Promise<VideoInfo> {
  try {
    const apiUrl = `${API_BASE_URL}/api/video-info`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ message: 'An unknown error occurred.' }));
      throw new Error(errorData.message || 'Failed to fetch video information from the server.');
    }

    const data: VideoInfo = await response.json();
    return data;

  } catch (error) {
    console.error("Error fetching video info:", error);
    if (error instanceof Error) {
        throw new Error(error.message);
    }
    throw new Error("A network error occurred while fetching video information.");
  }
}