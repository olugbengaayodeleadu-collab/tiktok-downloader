import express, { Request, Response } from 'express';
import axios from 'axios';
import cheerio from 'cheerio';
import cors from 'cors';
import path from 'path';
// Fix: Add `url` import to define `__dirname` in an ES module environment.
import { fileURLToPath } from 'url';

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors()); // Enable CORS for all routes (useful for dev environment)
app.use(express.json());

interface VideoInfo {
  title: string;
  author: string;
  thumbnailUrl: string;
  downloadUrls: {
    noWatermark: string;
    withWatermark: string;
    mp3: string;
  };
}

// API Route
app.post('/api/video-info', async (req: Request, res: Response) => {
  const { url } = req.body;

  if (!url || typeof url !== 'string') {
    return res.status(400).json({ message: 'URL is required.' });
  }

  try {
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      },
    });

    const $ = cheerio.load(response.data);
    const scriptTag = $('#SIGI_STATE');
    if (!scriptTag.length) {
      throw new Error('Could not find video data script tag. The page structure might have changed or the URL is invalid.');
    }
    
    const jsonData = JSON.parse(scriptTag.html() || '{}');
    const itemModule = jsonData.ItemModule;
    if (!itemModule || Object.keys(itemModule).length === 0) {
        throw new Error('ItemModule not found in page data. The video may be private or the URL is incorrect.');
    }
    const videoId = Object.keys(itemModule)[0];
    const videoData = itemModule[videoId];

    if (!videoData) {
        throw new Error('Video data not found in the JSON object.');
    }

    const result: VideoInfo = {
      title: videoData.desc,
      author: videoData.author,
      thumbnailUrl: videoData.video.cover,
      downloadUrls: {
        noWatermark: videoData.video.playAddr,
        withWatermark: videoData.video.downloadAddr,
        mp3: videoData.music.playUrl,
      },
    };

    return res.status(200).json(result);

  } catch (error) {
    console.error('Scraping error:', error);
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred during scraping.';
    res.status(500).json({ message: `Failed to process TikTok URL. ${errorMessage}` });
  }
});

// --- Serving Frontend ---
// In a CommonJS module (as defined by tsconfig.json), __dirname is a global variable.
// The compiled server.js will be in 'dist/backend', so we go up one level to find the 'dist' folder.
// Fix: `__dirname` is not available in ES modules. This creates a polyfill for it.
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const frontendDistPath = path.resolve(__dirname, '..');

// Serve static files (index.js, etc.) from the 'dist' directory
app.use(express.static(frontendDistPath));

// For any other request, send the main index.html file so the React app can handle routing
app.get('*', (req, res) => {
  res.sendFile(path.join(frontendDistPath, 'index.html'));
});


app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});