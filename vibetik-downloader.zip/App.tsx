import React, { useState } from 'react';
import type { VideoInfo } from './types';
import { fetchVideoInfo } from './services/videoService';
import { Header } from './components/Header';
import { UrlInputForm } from './components/UrlInputForm';
import { ResultCard } from './components/ResultCard';
import { LoadingSpinner } from './components/LoadingSpinner';
import { HowToUse } from './components/HowToUse';
import { Footer } from './components/Footer';

function App() {
  const [url, setUrl] = useState<string>('');
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!url.trim()) {
      setError('Please enter a TikTok URL.');
      return;
    }
    
    // Basic URL validation
    try {
        new URL(url);
    } catch (_) {
        setError('Please enter a valid URL.');
        return;
    }

    setIsLoading(true);
    setError(null);
    setVideoInfo(null);

    try {
      const data = await fetchVideoInfo(url);
      setVideoInfo(data);
    } catch (err) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(`Could not process the video link. Please check the URL and try again. (${errorMessage})`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-900 text-gray-200">
      <Header />
      <main className="flex-grow flex flex-col items-center justify-center p-4 sm:p-6 text-center">
        <div className="w-full max-w-3xl mx-auto">
          <h1 className="text-4xl sm:text-5xl font-extrabold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
            TikTok Video Downloader
          </h1>
          <p className="text-lg text-gray-400 mb-8 max-w-2xl mx-auto">
            Paste a link to a TikTok video to download it without a watermark. Simple, fast, and free.
          </p>
          
          <UrlInputForm
            url={url}
            setUrl={setUrl}
            handleSubmit={handleSubmit}
            isLoading={isLoading}
          />
          
          <div className="mt-8 min-h-[200px] flex items-center justify-center">
            {isLoading && <LoadingSpinner />}
            {error && <div className="text-red-400 bg-red-900/50 p-4 rounded-lg">{error}</div>}
            {videoInfo && !isLoading && <ResultCard videoInfo={videoInfo} />}
          </div>
        </div>
      </main>
      <HowToUse />
      <Footer />
    </div>
  );
}

export default App;
